import './App.css';
import SideBar from "./components/Navig/side-bar";
import TopBar from './components/Navig/top-bar';
import Dashboard from './components/Dashbrd/Dashboard';
import Analytics from './components/Analytics/Analytics';
import SolidWasteManagement from './components/charts/SolidWasteMemnt/SolidWasteManagement';
import Advice from './components/Advice/Advice'
import GraphView from './components/charts/SolidWasteMemnt/GraphView';
import CcTv from './components/charts/CCTV/CcTv'
import Aqi from './components/charts/AQI/Aqi'
import Trafficdata from './components/charts/Traffic/Trafficdata';
import Adv from './components/Advice/Adv'
// import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { BrowserRouter as Router, NavLink, Route, Routes } from 'react-router-dom'
import './components/Navig/side-bar.css'
import './components/Navig/top-bar.css'
import 'leaflet/dist/leaflet.css'
import NewTopBar from './components/Navig/newTopBar'
function App() {

  return (
    <div className="App">
      <Router>
        {/* <NewTopBar/> */}
        <TopBar />
        <SideBar />
        <Routes>
        <Route exact path="/dashboard" element={<Dashboard/>} />
        <Route path="/SolidWastemanagment" element={<SolidWasteManagement />} />
        <Route path="/CcTv" element={<CcTv/>} />
        <Route path="/Aqi" element={<Aqi/>} />
        <Route path="/Trafficdata" element={<Trafficdata/>} />
        

        <Route path="/Analytics" element={<Analytics />} />
        <Route path="/Datasrc" element={<Analytics />} />
        <Route path="/MlWorkBench" element={<Analytics />} />
        <Route path="/Advice" element={<Adv />} />
        <Route path="/Settings" element={<Analytics />} />
        <Route exact path="/SolidWastemanagment/:graphView" element={<GraphView />} />
        
        
        </Routes>
        
        </Router>


    </div>
  );
}

export default App;
