import React, { useState } from "react";
import SunburstS from "./SunburstS";
import Dumbbell from "./Dumbbell";
import SolidWasteForcast from "./SolidwasteForcast";
import LineChartTraffic from "./LineChartTraffic";
import "./SolidWasteManagement.css";
import { useNavigate } from "react-router-dom";
function SolidWasteManagement() {
  // const [showGraph, setShowGraph] = useState(false);
  // const [selectedGraph, setSelectedGraph] = useState('');
const navigate = useNavigate();
const handleClick = (graph) => {
  navigate(`/SolidWastemanagment/${graph}`)
}
  return (
    <div className="graph-container">
        <div class="container">
          <div
            class="card"
            onClick={()=>handleClick('classificationOfComplains')}
          >
            {/* <SunburstS/> */}
            <LineChartTraffic />
          </div>
          <div class="card">
            {/* <Dumbbell/> */}
            <LineChartTraffic />
          </div>
          <div class="card">
            {/* <SolidWasteForcast/> */}
            <LineChartTraffic />
          </div>

          <div class="card">
            <LineChartTraffic />
          </div>
          <div class="card">
            <LineChartTraffic />
          </div>
          <div class="card">
            <LineChartTraffic />
          </div>
        </div>
      
      <div class="button-container">
        <button>Button 1</button>
        <button>Button 2</button>
        <button>Button 3</button>
        <button>Button 4</button>
      </div>

      {/* SolidWasteManagement
      <SunburstS/>
      Dumbbell
      <Dumbbell/>
      SolidWasteForcast
      <SolidWasteForcast/>
      LineChartTraffic
      <LineChartTraffic/> */}
    </div>
  );
}

export default SolidWasteManagement;
