import React from 'react'


function CcTv() {
  return (
    <div className="graph-container">
    <h1>  this is under development CCTV
       </h1>
       </div>
  )
}

export default CcTv