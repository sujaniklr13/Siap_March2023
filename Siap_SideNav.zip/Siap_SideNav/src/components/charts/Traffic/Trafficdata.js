import React from 'react'

function Trafficdata() {
  return (
    <div className="graph-container">
    <h1>  this is under development Traffic
       </h1>
       </div>
  )
}

export default Trafficdata