import React from 'react'

function DetailGraphView() {
  return (
    <div>DetailGraphView</div>
  )
}

export default DetailGraphView