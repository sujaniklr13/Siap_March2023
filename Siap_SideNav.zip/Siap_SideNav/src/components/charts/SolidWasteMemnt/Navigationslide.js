import React from 'react'
import "./SolidWasteManagement.css";
import { useNavigate } from "react-router-dom";

function Navigationslide() {
const navigate = useNavigate();

    const handleClick1 = (graph) => {
        navigate(`/${graph}`)
      }
  return (
    <div className="buttons">
            <div className="menu button"  onClick={()=>handleClick1('dashboard')}>
                <img src="./images/chevron-left.svg" alt="" />
                <img src="./images/dshbrd.svg" alt="" />
            </div> 
            <div className="menu button"  onClick={()=>handleClick1('SolidWastemanagment')}>
                <img src="./images/chevron-left.svg" alt="" />
                <img src="./images/solidwate-management.png" alt="" />
            </div>
            <div className="navigate-buttons"> 
                <button className="name-img" onClick={()=>handleClick1('')}>
                    <img src="./images/solid-waste-management.png" alt="" />
                    <h3 className='m-0'>PropTypes.exact({
                      
                    }).isRequired</h3>
                </button>
                <button className="name-img">
                    <img src="./images/leaf.png" alt="" />
                    <h3 className='m-0'>curr</h3>
                </button>
                <button className="name-img"onClick={()=>handleClick1('')}>
                    <img src="./images/traffic.png" alt="" />
                    <h3 className='m-0'>nxt</h3>
                </button>
            </div>
        </div>
  )
}

export default Navigationslide