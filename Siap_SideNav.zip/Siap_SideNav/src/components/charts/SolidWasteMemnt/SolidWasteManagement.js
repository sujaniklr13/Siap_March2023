import React, { useState } from "react";
import SunburstS from "./SunburstS";
import Dumbbell from "./Dumbbell";
import SolidWasteForcast from "./SolidwasteForcast";
import LineChartTraffic from "./LineChartTraffic";
import MonthlyComplaints from './MonthlyComplaints';
import BarChart from "./BarChart";
import ClosedPercentage from './Closedpercentage';
import "./SolidWasteManagement.css";
import { useNavigate } from "react-router-dom";
import DynamicChart from "./DynamicChart";

function SolidWasteManagement() {
  // const [showGraph, setShowGraph] = useState(false);
  // const [selectedGraph, setSelectedGraph] = useState('');
  const navigate = useNavigate();
  const handleClick = (graph) => {
    navigate(`/SolidWastemanagment/${graph}`);
  };
  const handleClick1 = (graph) => {
    navigate(`/${graph}`);
  };

  return (
    <div className="graph-container">
      {/* <div class="container"> */}
        <div className="row">
          <div className="col-12 col-lg-12 col-xl-12">
          <div className="row"
          // onClick={() => handleClick("classificationOfComplains")}
          >
            {/* <div
              class="card"
              onClick={() => handleClick("classificationOfComplains")}
            > */}
            
              <DynamicChart
                ChartComp={<SunburstS />}
                name="Classification Of Complaints"
                screen="col-12 col-lg-4 col-xl-4 d-flex"
                onClick={() => handleClick1("classificationOfComplains")}
                />
          
              {/* <SunburstS/> */}
              {/* <LineChartTraffic /> */}
            {/* </div> */}
            {/* <div
              class="card"
              onClick={() => handleClick("Complainscomparition")}
            > */}
              <DynamicChart
                ChartComp={<Dumbbell />}
                name="Complaints Comparition March-2022 to October 2022"
                screen="col-12 col-lg-4 col-xl-4 d-flex"
              />
         
              <DynamicChart
                ChartComp={<SolidWasteForcast />}
                name="Total Complaints Forecast for next 4 weeks"
                screen="col-12 col-lg-4 col-xl-4 d-flex"
              />
           
          </div>
          <div className="row">
           
             
                <DynamicChart
                  ChartComp={<MonthlyComplaints />}
                  name="Complaints Reported Across all Zones per Month"
                  screen="col-12 col-lg-4 col-xl-4 d-flex"
                />
                {/* <SunburstS/> */}
                {/* <LineChartTraffic /> */}
              {/* </div> */}
              {/* <div
                class="card"
                onClick={() => handleClick("Complainscomparition")}
              > */}
                <DynamicChart
                  ChartComp={<BarChart />}
                  name="Total Complaints Across Zones"
                  screen="col-12 col-lg-4 col-xl-4 d-flex"
                />
           
                <DynamicChart
                  ChartComp={<ClosedPercentage />}
                  name="Percentage Of Closed Complaints"
                  screen="col-12 col-lg-4 col-xl-4 d-flex"
                />
              
            </div>
            
            
          <div className="row">
            <div className="buttons">
              <div
                className="menu button"
                onClick={() => handleClick1("dashboard")}
              >
                <img src="./images/chevron-left.svg" alt="" />
                <img src="./images/dshbrd.svg" alt="" />
              </div>
              <div className="navigate-buttons">
                <button
                  className="name-img "
                  onClick={() => handleClick1("SolidWastemanagment")}
                >
                  <img src="./images/solid-waste-management.png" alt="" />
                  <h3 className="m-0">Solid Waste Management</h3>
                </button>
                <button
                  className="name-img"
                  onClick={() => handleClick1("CcTv")}
                >
                  <img src="./images/cctv.png" alt="" />
                  <h3 className="m-0">CCTV</h3>
                </button>
                <button
                  className="name-img"
                  onClick={() => handleClick1("Aqi")}
                >
                  <img src="./images/leaf.png" alt="" />
                  <h3 className="m-0">Air Quality Index</h3>
                </button>
                <button
                  className="name-img"
                  onClick={() => handleClick1("Trafficdata")}
                >
                  <img src="./images/traffic.png" alt="" />
                  <h3 className="m-0">Traffic</h3>
                </button>
              </div>
            
           
        
        </div>
        </div>
      {/* </div> */}
    </div></div></div>
  );
}

export default SolidWasteManagement;
