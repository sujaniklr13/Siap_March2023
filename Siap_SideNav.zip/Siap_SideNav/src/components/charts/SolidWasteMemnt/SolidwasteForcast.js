import React, { useEffect, useState } from "react";
import Highcharts from "highcharts/highcharts.js";
import HighchartsReact from "highcharts-react-official";
import HC_exporting from "highcharts/modules/exporting";
import styles from './SolidWasteForcast.module.css'

HC_exporting(Highcharts);
var zoneA = [{ "Date": "2022-03-27", "Value": 4.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-03", "Value": 4.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-10", "Value": 4.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-17", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-24", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-01", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-08", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-15", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-22", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-29", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-05", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-12", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-19", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-26", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-03", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-10", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-17", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-24", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-31", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-07", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-14", "Value": 16.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-21", "Value": 18.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-28", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-04", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-11", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-18", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-25", "Value": 10.0, "Type": "Actual", "Validation": 10.0 }, { "Date": "2022-10-02", "Value": 10.0, "Type": "Actual", "Validation": 10.0 }, { "Date": "2022-10-09", "Value": 10.0, "Type": "Actual", "Validation": 10.0 }, { "Date": "2022-10-16", "Value": 10.0, "Type": "Actual", "Validation": 10.0 }, { "Date": "2022-10-23", "Value": 10.0, "Type": "Predicted", "Validation": null }, { "Date": "2022-10-30", "Value": 10.0, "Type": "Predicted", "Validation": null }]
var zoneB = [{ "Date": "2022-02-20", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-02-27", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-06", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-13", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-20", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-27", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-03", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-10", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-17", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-24", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-01", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-08", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-15", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-22", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-29", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-05", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-12", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-19", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-26", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-03", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-10", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-17", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-24", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-31", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-07", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-14", "Value": 6.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-21", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-28", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-04", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-11", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-18", "Value": 12.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-25", "Value": 12.0, "Type": "Actual", "Validation": 8.0 }, { "Date": "2022-10-02", "Value": 12.0, "Type": "Actual", "Validation": 9.0 }, { "Date": "2022-10-09", "Value": 12.0, "Type": "Actual", "Validation": 9.0 }, { "Date": "2022-10-16", "Value": 18.0, "Type": "Actual", "Validation": 9.0 }, { "Date": "2022-10-23", "Value": 19.0, "Type": "Predicted", "Validation": null }, { "Date": "2022-10-30", "Value": 21.0, "Type": "Predicted", "Validation": null }]
var zoneC = [{ "Date": "2022-02-20", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-02-27", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-06", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-13", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-20", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-27", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-03", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-10", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-17", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-24", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-01", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-08", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-15", "Value": 8.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-22", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-29", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-05", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-12", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-19", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-26", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-03", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-10", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-17", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-24", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-31", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-07", "Value": 9.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-14", "Value": 11.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-21", "Value": 11.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-28", "Value": 11.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-04", "Value": 11.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-11", "Value": 11.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-18", "Value": 15.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-25", "Value": 15.0, "Type": "Actual", "Validation": 11.0 }, { "Date": "2022-10-02", "Value": 15.0, "Type": "Actual", "Validation": 11.0 }, { "Date": "2022-10-09", "Value": 15.0, "Type": "Actual", "Validation": 11.0 }, { "Date": "2022-10-16", "Value": 15.0, "Type": "Actual", "Validation": 11.0 }, { "Date": "2022-10-23", "Value": 15.0, "Type": "Predicted", "Validation": null }, { "Date": "2022-10-30", "Value": 15.0, "Type": "Predicted", "Validation": null }]
var zoneD = [{ "Date": "2022-02-20", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-02-27", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-06", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-13", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-20", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-27", "Value": 10.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-03", "Value": 12.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-10", "Value": 48.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-17", "Value": 52.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-24", "Value": 60.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-01", "Value": 62.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-08", "Value": 62.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-15", "Value": 62.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-22", "Value": 62.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-29", "Value": 62.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-05", "Value": 62.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-12", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-19", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-26", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-03", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-10", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-17", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-24", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-31", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-07", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-14", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-21", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-28", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-04", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-11", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-18", "Value": 64.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-25", "Value": 64.0, "Type": "Actual", "Validation": 64.0 }, { "Date": "2022-10-02", "Value": 64.0, "Type": "Actual", "Validation": 64.0 }, { "Date": "2022-10-09", "Value": 64.0, "Type": "Actual", "Validation": 64.0 }, { "Date": "2022-10-16", "Value": 64.0, "Type": "Actual", "Validation": 64.0 }, { "Date": "2022-10-23", "Value": 64.0, "Type": "Predicted", "Validation": null }, { "Date": "2022-10-30", "Value": 64.0, "Type": "Predicted", "Validation": null }]
var zoneE = [{ "Date": "2022-02-20", "Value": 28.0, "Type": "Actual", "Validation": null }, { "Date": "2022-02-27", "Value": 28.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-06", "Value": 28.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-13", "Value": 28.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-20", "Value": 28.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-27", "Value": 42.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-03", "Value": 42.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-10", "Value": 42.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-17", "Value": 36.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-24", "Value": 36.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-01", "Value": 36.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-08", "Value": 36.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-15", "Value": 38.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-22", "Value": 38.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-29", "Value": 38.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-05", "Value": 38.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-12", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-19", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-26", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-03", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-10", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-17", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-24", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-31", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-07", "Value": 40.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-14", "Value": 44.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-21", "Value": 54.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-28", "Value": 42.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-04", "Value": 50.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-11", "Value": 50.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-18", "Value": 50.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-25", "Value": 54.0, "Type": "Actual", "Validation": 48.0 }, { "Date": "2022-10-02", "Value": 54.0, "Type": "Actual", "Validation": 48.0 }, { "Date": "2022-10-09", "Value": 58.0, "Type": "Actual", "Validation": 48.0 }, { "Date": "2022-10-16", "Value": 58.0, "Type": "Actual", "Validation": 48.0 }, { "Date": "2022-10-23", "Value": 58.0, "Type": "Predicted", "Validation": null }, { "Date": "2022-10-30", "Value": 58.0, "Type": "Predicted", "Validation": null }]
var zoneF = [{ "Date": "2022-02-20", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-02-27", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-06", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-13", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-20", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-03-27", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-03", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-10", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-17", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-24", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-01", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-08", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-15", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-22", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-29", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-05", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-12", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-19", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-26", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-03", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-10", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-17", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-24", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-31", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-07", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-14", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-21", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-28", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-04", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-11", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-18", "Value": 2.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-25", "Value": 2.0, "Type": "Actual", "Validation": 2.0 }, { "Date": "2022-10-02", "Value": 2.0, "Type": "Actual", "Validation": 2.0 }, { "Date": "2022-10-09", "Value": 2.0, "Type": "Actual", "Validation": 2.0 }, { "Date": "2022-10-16", "Value": 2.0, "Type": "Actual", "Validation": 2.0 }, { "Date": "2022-10-23", "Value": 2.0, "Type": "Predicted", "Validation": null }, { "Date": "2022-10-30", "Value": 2.0, "Type": "Predicted", "Validation": null }]
var zoneG = [{ "Date": "2022-03-27", "Value": 0.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-03", "Value": 0.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-10", "Value": 0.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-17", "Value": 0.0, "Type": "Actual", "Validation": null }, { "Date": "2022-04-24", "Value": 0.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-01", "Value": 0.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-08", "Value": 0.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-15", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-22", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-05-29", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-05", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-12", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-19", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-06-26", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-03", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-10", "Value": 3.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-17", "Value": 7.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-24", "Value": 11.0, "Type": "Actual", "Validation": null }, { "Date": "2022-07-31", "Value": 17.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-07", "Value": 17.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-14", "Value": 17.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-21", "Value": 17.0, "Type": "Actual", "Validation": null }, { "Date": "2022-08-28", "Value": 17.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-04", "Value": 17.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-11", "Value": 17.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-18", "Value": 17.0, "Type": "Actual", "Validation": null }, { "Date": "2022-09-25", "Value": 16.0, "Type": "Actual", "Validation": 17.0 }, { "Date": "2022-10-02", "Value": 16.0, "Type": "Actual", "Validation": 17.0 }, { "Date": "2022-10-09", "Value": 16.0, "Type": "Actual", "Validation": 17.0 }, { "Date": "2022-10-16", "Value": 16.0, "Type": "Actual", "Validation": 17.0 }, { "Date": "2022-10-23", "Value": 16.0, "Type": "Predicted", "Validation": null }, { "Date": "2022-10-30", "Value": 16.0, "Type": "Predicted", "Validation": null }]
var zoneH = [{ "Date": "2022-03-27", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-04-03", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-04-10", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-04-17", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-04-24", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-05-01", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-05-08", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-05-15", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-05-22", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-05-29", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-06-05", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-06-12", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-06-19", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-06-26", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-07-03", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-07-10", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-07-17", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-07-24", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-07-31", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-08-07", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-08-14", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-08-21", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-08-28", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-09-04", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-09-11", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-09-18", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-09-25", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-10-02", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-10-09", "Value": 0.0, "Type": "Actual" }, { "Date": "2022-10-16", "Value": 0.0, "Type": "Actual" }]

var zoneAresult = { 'Model': 'ARIMA', 'Stationary': 'Yes', 'X_train': '24 Weeks', 'X_test': '2 Weeks', 'X_validation': '4 Weeks', 'ARIMA_order': '(0, 1, 0)', 'MSE': 0.0, 'RMSE': 0.0, 'MAPE': 0.0, 'Accuracy': 100.0 }
var zoneBresult = { 'Model': 'ARIMA', 'Stationary': 'No', 'X_train': '29 Weeks', 'X_test': '2 Weeks', 'X_validation': '4 Weeks', 'ARIMA_order': '(0, 2, 1)', 'MSE': 6.813251774095902, 'RMSE': 2.610220637052719, 'MAPE': 0.1634178548186879, 'Accuracy': 84.0 }
var zoneCresult = { 'Model': 'ARIMA', 'Stationary': 'No', 'X_train': '29 Weeks', 'X_test': '2 Weeks', 'X_validation': '4 Weeks', 'ARIMA_order': '(0, 1, 0)', 'MSE': 8.0, 'RMSE': 2.8284271247461903, 'MAPE': 0.13333333333333333, 'Accuracy': 87.0 }
var zoneDresult = { 'Model': 'ARIMA', 'Stationary': 'Yes', 'X_train': '29 Weeks', 'X_test': '2 Weeks', 'X_validation': '4 Weeks', 'ARIMA_order': '(0, 1, 0)', 'MSE': 0.0, 'RMSE': 0.0, 'MAPE': 0.0, 'Accuracy': 100.0 }
var zoneEresult = { 'Model': 'ARIMA', 'Stationary': 'No', 'X_train': '29 Weeks', 'X_test': '2 Weeks', 'X_validation': '4 Weeks', 'ARIMA_order': '(0, 1, 1)', 'MSE': 3.275092347012182, 'RMSE': 1.8097216214136864, 'MAPE': 0.03619443242827373, 'Accuracy': 96.0 }
var zoneFresult = { 'Model': 'ARIMA', 'Stationary': 'No', 'X_train': '29 Weeks', 'X_test': '2 Weeks', 'X_validation': '4 Weeks', 'ARIMA_order': '(0, 0, 0)', 'MSE': 2.3276361497920984e-11, 'RMSE': 4.8245581660832926e-06, 'MAPE': 2.4122790830416463e-06, 'Accuracy': 100.0 }
var zoneGresult = { 'Model': 'ARIMA', 'Stationary': 'No', 'X_train': '24 Weeks', 'X_test': '2 Weeks', 'X_validation': '4 Weeks', 'ARIMA_order': '(1, 1, 0)', 'MSE': 0.0, 'RMSE': 0.0, 'MAPE': 0.0, 'Accuracy': 100.0 }
var zoneHresult = null

const AQIZonesData = [
    { zone: 'Zone A', data: zoneA },
    { zone: 'Zone B', data: zoneB },
    { zone: 'Zone C', data: zoneC },
    { zone: 'Zone D', data: zoneD },
    { zone: 'Zone E', data: zoneE },
    { zone: 'Zone F', data: zoneF },
    { zone: 'Zone G', data: zoneG },
    { zone: 'Zone H', data: zoneH },
]

const SolidWasteForcast = () => {
    const [zones, setZones] = useState("Zone A")
    const [state, setState] = useState(zoneA)
    const [active, setActive] = useState(0)
    const [result, setResult] = useState(zoneAresult)
    const [modal, setModal] = useState(false)

    var date = []
    var fdata = []
    var validation = []
    const clickHandler = (zone) => {
        if (zone === 'Zone A') {
            setState(zoneA)
            setResult(zoneAresult)
            setZones('Zone A')
            setActive(0)
        }
        if (zone === 'Zone B') {
            setResult(zoneBresult)
            setState(zoneB)
            setActive(1)
            setZones('Zone B')
        }
        if (zone === 'Zone C') {
            setState(zoneC)
            setResult(zoneCresult)
            setActive(2)
            setZones('Zone C')
        }
        if (zone === 'Zone D') {
            setState(zoneD)
            setResult(zoneDresult)
            setActive(3)
            setZones('Zone D')
        }
        if (zone === 'Zone E') {
            setResult(zoneEresult)
            setState(zoneE)
            setActive(4)
            setZones('Zone E')
        }
        if (zone === 'Zone F') {
            setState(zoneF)
            setResult(zoneFresult)
            setActive(5)
            setZones('Zone F')
        }
        if (zone === 'Zone G') {
            setState(zoneG)
            setResult(zoneGresult)
            setActive(6)
            setZones('Zone G')
        }
        if (zone === 'Zone H') {
            setState(zoneH)
            setResult(zoneHresult)
            setActive(7)
            setZones('Zone H')
        }
    }

    console.log(state);
    state.map((item) => {

        date.push(item.Date)
        validation.push({ y: item.Validation, date: item.Date, type: "validation" })
        fdata.push({
            type: item.Type,
            date: item.Date,
            y: Math.round(item.Value),
            color: getColor(item.Type)
        })
    })

    const buttonHandler = () => {
        setModal(!modal)
    }
    var c = ""
    function getColor(a) {
        if (a === "Actual") {
            c = "blue"
        }
        if (a === "Predicted") {
            c = "red"
        }
        return c
    }

    const options = {
        chart: {
            type: "line",
            zoomType: 'xy',
            backgroundColor: '#263238',
            spacing: 40,
            borderRadius: 16,
            height:"250px",
            events: {
                load: function () {
                    let data = this.series[0].data
                    console.log(data);
                    // for (let i = 0; i < data.length; i++) {
                    //     console.log(data[i].options.type);
                    //     if (data[i].options.type === 'Predicted') {
                    //         data[i].update({ color: "hsla(4.11,89.62%,58.43%)" })

                    //     }
                    //     else {
                    //         data[i].update({ color: "hsla(206.57,89.74%,54.12%)" })

                    //     }

                    // }
                }
            }
        },
        title: {
            style: {
                color: 'white',
                font: 'bold 20px',
            },
            text: zones,
        },
        subtitle: {
            text: "",
        },
        xAxis: {
            categories: date,
            title: {
                text: "Date",
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        yAxis: {
            gridLineColor: "none",
            title: {
                text: "Value",
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        tooltip: {
            formatter: function () {
                // console.log(this.point);
                if (this.point.type === 'validation') {
                    return '<b> Validation : </b>' + this.point.y + '<br><b>Date :</b>' + this.point.date

                }
                else if (this.point.type === "Actual" || this.point.type === "Predicted") {
                    return '<b> Complaints : </b>' + this.point.y + '<br><b>Type :</b>' +
                        this.point.type + '<br><b>Date </b>:' + this.point.date
                }
            }
        },
        plotOptions: {
            bar: {
                dataLabels: {
                    enabled: false,
                },
            },
        },
        legend: {
            itemStyle: {
                color: 'white',
                font: 'bold 20px',
            },
            enabled: true,
            layout: "horizontal",
            align: "center",
            verticalAlign: "bottom",
            x: 0,
            y: 0,
            floating: false,
            borderWidth: 1,
        },
        credits: {
            enabled: false,
        },
        series:
            [{
                marker: {
                    enabled: true
                },
                name: 'Actual',
                data: fdata,
                // colorByPoint: true,
                lineColor: "#676c67",
                color: "blue",


            },
            {
                name: "Predicted",

                color: "red"
            },
            {
                name: "Validation",
                data: validation,
                color: "yellow"
            }
            ]  // },
    };
    console.log(result);
    return (
        <>

            <div style={{ width: "100%" }}>
                <HighchartsReact highcharts={Highcharts} options={options} />
            </div>


            {/* <div className={styles.buttonContainer}>
                <div className={styles.buttonInnerContainer}>
                    {AQIZonesData.map((data, id) => (
                        <button
                            style={{ backgroundColor: active === id ? "#FAC105" : "" }}
                            className={styles.button} onClick={() => clickHandler(data.zone, id)}>
                            {data.zone}</button>
                    ))}
                </div>

            </div> */}

            {/* <div className={styles.tablebox_outerContainer}>
                <div className={styles.tablebox}>

                    {modal &&
                        <div>
                            {result && (
                                <table>

                                    <tr>
                                        <td>Model</td>
                                        <td>ARIMA</td>
                                    </tr>

                                    <tr>
                                        <td>Stationary</td>
                                        <td>{result.Stationary}</td>
                                    </tr>
                                    <tr>
                                        <td>Train Size</td>
                                        <td>{result.X_train} </td>
                                    </tr>
                                    <tr>
                                        <td>Test Size</td>
                                        <td>{result.X_test} </td>
                                    </tr>
                                    <tr>
                                        <td>Validation Size</td>
                                        <td>{result.X_validation}</td>
                                    </tr>
                                    <tr>
                                        <td>ARIMA Order</td>
                                        <td>{result.ARIMA_order}</td>
                                    </tr>
                                    <tr>
                                        <td>Root Mean Squared Error</td>
                                        <td>{result.RMSE.toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                        <td>Mean Absolute Percentage Error</td>
                                        <td>{result.MAPE.toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                        <td>Accuracy Percentage</td>
                                        <td>{result.Accuracy}</td>
                                    </tr>
                                </table>
                            )}
                        </div>

                    }
                    {!modal && result != null && < table >
                        <tr>
                            <td>Model</td>
                            <td>ARIMA</td>
                        </tr></table>}
                    {result != null &&
                        <button onClick={buttonHandler}>{!modal ? "View More" : "View Less"}</button>}
                    {result === null && (
                        <div style={{display:"flex",justifyContent:"center",marginTop:'1rem'}}><div className={styles.warning}>!</div><div>Data is insufficient for analysis</div></div>
                    )}
                </div>
            </div> */}

        </>
    );
};

export default SolidWasteForcast;
