import {  useParams } from "react-router-dom";
import LineChartTraffic from "./LineChartTraffic";
import SolidWasteForcast from "./SolidwasteForcast"
import SunburstS from "./SunburstS";
import { useNavigate } from "react-router-dom";
import "./Graphview.css";
import Logo from "./IMG/DB2.png";
import SWM  from "./IMG/solid-waste-management.png";
import DynamicChart from "./DynamicChart";
function GraphView() {
  const navigate = useNavigate();
  const handleClick1 = (graph) => {
    navigate(`/${graph}`)
  }

    const {graphView} = useParams();
    console.log('a',graphView)
    const renderChart = () => {
        switch(graphView) {
          case 'classificationOfComplains':
            return <DynamicChart
            ChartComp={<SunburstS />}
            name="Classification Of Complaints"
            screen="col-12 col-lg-12 col-xl-12 d-flex"
            />;
         case 'Complainscomparition':
              return <SolidWasteForcast/>;
        }
      }
    return (
    <div className="graph-container">
              <div style={{paddingTop: "70px"}}>
                {renderChart()}
              </div>

           {/* <div className="buttons">
            <div className="menu button1"  onClick={()=>handleClick1('dashboard')}>
                <img src="./images/chevron-left.svg" alt="" />
                <img src="./images/dshbrd.svg" alt="" />
            </div> 
            <div className="menu button1"  onClick={()=>handleClick1('SolidWastemanagment')}>
                <img src="./images/chevron-left.svg" alt="" />
                <img src="./images/dshbrd.svg" alt="" />
            </div> 
            <div className="navigate-buttons1"> 
                <button className="name-img4" onClick={()=>handleClick1('SolidWastemanagment')}>
                   
                    <h3 className='m-0'>previous</h3>
                </button>
  
                <button className="name-img4"onClick={()=>handleClick1('Trafficdata')}>
                   
                    <h3 className='m-0'>Next</h3>
                </button>
        </div>
        </div>  */}
        <div class="but-container">
       
  <button class="m-0 button1"onClick={()=>handleClick1('dashboard')}>
  <img src={Logo} alt="O" style={{width:"20px",heigth:"20px"}} />
  {/* <img src="./images/dshbrd.svg" alt="log1" style={{width:"10px",heigth:"20px"}}/> */}

    </button>

  <button class="button1"onClick={()=>handleClick1('SolidWastemanagment')}>
  <img src={SWM} alt="O" style={{width:"20px",heigth:"20px"}} />
    </button>
  <button class="button2">Pre</button>
  <button class="button2">NXT</button>
</div>
        </div>
    );
}

export default GraphView;