import React from 'react'
import { useNavigate } from "react-router-dom";

function DynamicChart({ ChartComp, name, screen }) {
 const navigate = useNavigate();
 const handleClick = (ChartComp) => {
  navigate(`/SolidWastemanagment/${ChartComp}`);
};
  return (
        <>
          <div className={screen}>
            <div className="card w-100"
          
            >
              <div className="row">{ChartComp}</div>
              <div>
                <h6 className="m-2 p-3">{name}</h6>
              </div>
            </div>
          </div>
        </> 
      );
    };

export default DynamicChart