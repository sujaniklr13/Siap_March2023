import React, { useEffect, useState } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import highchartsDumbbell from "highcharts/modules/dumbbell";
import HC_more from "highcharts/highcharts-more";
import { BarchartData, LineChartTrafficData } from "./dmmydata";
// import styles from './Solid.module.css'
// import moment from "moment";
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
require('highcharts/modules/annotations')(Highcharts);


HC_more(Highcharts);
var chartTypeDropDown = ['line', 'column', 'scatter']
var LocationsDropdown = ['A Zone Office PCMC', 'Sambhaji Chowk']
var itemsDropDown = ['Congestion Percentage', 'Average Speed', 'Current Flow', 'Occupancy Percentage']
const LineChartTraffic = () => {
    var item0_6 = []
    var item6_12 = []
    var item12_18 = []
    var item18_24 = []
    const congestion = []
    const timeOfTheDay = []
    var id = []


    // console.log(itemType);
    
        const locationFilter = LineChartTrafficData
        // console.log(locationFilter);
        const filterData0_6 = locationFilter.filter((data) => {
            return data["Time of the Day"] === '0-6'
        })
        const filterData6_12 = locationFilter.filter((data) => {
            return data["Time of the Day"] === '6-12'
        })
        const filterData12_18 = locationFilter.filter((data) => {
            return data["Time of the Day"] === '12-18'
        })
        const filterData18_24 = locationFilter.filter((data) => {
            return data["Time of the Day"] === '18-24'
        })
       filterData0_6.map((item)=>{
        item0_6.push(item["Average Speed"])
        id.push(item["Sensor ID"])
       })
       filterData6_12.map((item)=>{
        item6_12.push(item["Average Speed"])
        
       })
       filterData12_18.map((item)=>{
        item12_18.push(item["Average Speed"])
       
       })
       filterData18_24.map((item)=>{
        item18_24.push(item["Average Speed"])
        id.push(item["Sensor ID"])
       })
        // filterData0_6.map((item) => {
        //     const a = Object.fromEntries(Object.entries(item).filter(([key]) => key.includes(itemType)))
        //     for (var key in a) {
        //         if (a.hasOwnProperty(key)) {
        //             item0_6.push(a[key])
        //         }
        //     }
        //     id.push(item["Sensor ID"])
        // })

        // filterData6_12.map((item) => {
        //     const a = Object.fromEntries(Object.entries(item).filter(([key]) => key.includes(itemType)))
        //     for (var key in a) {
        //         if (a.hasOwnProperty(key)) {
        //             item6_12.push(a[key])
        //         }
        //     }
        // })
        // filterData12_18.map((item) => {
        //     const a = Object.fromEntries(Object.entries(item).filter(([key]) => key.includes(itemType)))
        //     for (var key in a) {
        //         if (a.hasOwnProperty(key)) {
        //             item12_18.push(a[key])
        //         }
        //     }
        // })
        // filterData18_24.map((item) => {
        //     const a = Object.fromEntries(Object.entries(item).filter(([key]) => key.includes(itemType)))
        //     for (var key in a) {
        //         if (a.hasOwnProperty(key)) {
        //             item18_24.push(a[key])
        //         }
        //     }
        // })
        
       
   




    const [chartOptions, setChartOptions] = useState({
        chart: {
            style: {
                fontFamily: "'Poppins', sans- serif",
                color: 'white'
            },
            type: 'line',
            zoomType: 'xy',
            backgroundColor: '#081a36',
            // spacing: 40,
            borderRadius: 16
        },
        title: {
            style: {
                color: 'white',
                font: 'bold 20px',

            },
            text: "",
        },
        subtitle: {
            text: "",
        },
        legend: {
            itemStyle: {
                color: 'white',
                font: 'bold 20px',
            },
            enabled: true
        },
        xAxis: {
            categories: id,
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "Sensor ID",
                // color: "red"
            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        yAxis: {
            gridLineColor: "#2e384a",
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "Values",

            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        plotOptions: {
            series: {
                borderColor: 'none'
            }
        },
        series: [
            {
                name: '0-6',
                color: '#cddc39',
                data: [... new Set(item0_6)]
            },
            {
                name: '6-12',
                color: 'red',
                data: [... new Set(item6_12)]
            },
            {
                name: '12-18',
                color: 'lightblue',
                data: [... new Set(item12_18)]
            },
            {
                name: '18-24',
                color: '#27df3c',
                data: [... new Set(item18_24)]
            }
        ],
        responsive: {
            rules: [{
                condition: {
                     // minHeight: 500
                },
                chartOptions: {
                    legend: {
                        enabled:false
                        // symbolHeight: 24,
                        // itemStyle: {
                        //     fontSize: '24px'
                        // }
                    },
                    title: {
                        style: {
                            fontSize: '32px',

                        }
                    },
                    xAxis: {
                        title: {
                            style: {
                                // fontSize: ' 16px'
                                fontSize: '12px'
                            },
                        },
                        labels: {
                            style: {
                                // fontSize: '16px'
                                fontSize:'12px'
                            }
                        },
                    },
                    yAxis: {

                        title: {
                            style: {
                                color: '#BBDEFB',
                                fontSize: ' 16px'
                            },

                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                }
            }]
        },
    });

    return (
        <div style={{ width: "100%" }}>


            <HighchartsReact highcharts={Highcharts} options={chartOptions} />

        </div>
    );
};


export default LineChartTraffic