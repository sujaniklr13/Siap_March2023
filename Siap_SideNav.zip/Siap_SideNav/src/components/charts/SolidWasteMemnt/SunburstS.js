import React, { useEffect, useState } from "react";

import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";
import HighchartsSunburst from "highcharts/modules/sunburst";
// import { SunburstData, sunburstNewData } from '../../dmmydata';

HighchartsSunburst(Highcharts);
const sdata =[{'id': 'A', 'parent': '', 'name': 'A'}, {'id': 'W_10_A', 'parent': 'A', 'name': 'W_10'}, {'id': 'Complaint_Close', 'parent': 'W_10_A', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_10_A', 'name': 'Complaint_Open', 'value': 3}, {'id': 'W_14_A', 'parent': 'A', 'name': 'W_14'}, {'id': 'Complaint_Close', 'parent': 'W_14_A', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_14_A', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_15_A', 'parent': 'A', 'name': 'W_15'}, {'id': 'Complaint_Close', 'parent': 'W_15_A', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_15_A', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_19_A', 'parent': 'A', 'name': 'W_19'}, {'id': 'Complaint_Close', 'parent': 'W_19_A', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_19_A', 'name': 'Complaint_Open', 'value': 1}, {'id': 'W_N_A', 'parent': 'A', 'name': 'W_N'}, {'id': 'Complaint_Close', 'parent': 'W_N_A', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_N_A', 'name': 'Complaint_Open', 'value': 4}, {'id': 'B', 'parent': '', 'name': 'B'}, {'id': 'W_16_B', 'parent': 'B', 'name': 'W_16'}, {'id': 'Complaint_Close', 'parent': 'W_16_B', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_16_B', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_17_B', 'parent': 'B', 'name': 'W_17'}, {'id': 'Complaint_Close', 'parent': 'W_17_B', 'name': 'Complaint_Close', 'value': 3}, {'id': 'Complaint_Open', 'parent': 'W_17_B', 'name': 'Complaint_Open', 'value': 2}, {'id': 'W_18_B', 'parent': 'B', 'name': 'W_18'}, {'id': 'Complaint_Close', 'parent': 'W_18_B', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_18_B', 'name': 'Complaint_Open', 'value': 3}, {'id': 'W_22_B', 'parent': 'B', 'name': 'W_22'}, {'id': 'Complaint_Close', 'parent': 'W_22_B', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_22_B', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_N_B', 'parent': 'B', 'name': 'W_N'}, {'id': 'Complaint_Close', 'parent': 'W_N_B', 'name': 'Complaint_Close', 'value': 3}, {'id': 'Complaint_Open', 'parent': 'W_N_B', 'name': 'Complaint_Open', 'value': 7}, {'id': 'C', 'parent': '', 'name': 'C'}, {'id': 'W_2_C', 'parent': 'C', 'name': 'W_2'}, {'id': 'Complaint_Close', 'parent': 'W_2_C', 'name': 'Complaint_Close', 'value': 2}, {'id': 'Complaint_Open', 'parent': 'W_2_C', 'name': 'Complaint_Open', 'value': 4}, {'id': 'W_6_C', 'parent': 'C', 'name': 'W_6'}, {'id': 'Complaint_Close', 'parent': 'W_6_C', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_6_C', 'name': 'Complaint_Open', 'value': 1}, {'id': 'W_8_C', 'parent': 'C', 'name': 'W_8'}, {'id': 'Complaint_Close', 'parent': 'W_8_C', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_8_C', 'name': 'Complaint_Open', 'value': 1}, {'id': 'W_9_C', 'parent': 'C', 'name': 'W_9'}, {'id': 'Complaint_Close', 'parent': 'W_9_C', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_9_C', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_N_C', 'parent': 'C', 'name': 'W_N'}, {'id': 'Complaint_Close', 'parent': 'W_N_C', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_N_C', 'name': 'Complaint_Open', 'value': 5}, {'id': 'D', 'parent': '', 'name': 'D'}, {'id': 'W_25_D', 'parent': 'D', 'name': 'W_25'}, {'id': 'Complaint_Close', 'parent': 'W_25_D', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_25_D', 'name': 'Complaint_Open', 'value': 24}, {'id': 'W_26_D', 'parent': 'D', 'name': 'W_26'}, {'id': 'Complaint_Close', 'parent': 'W_26_D', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_26_D', 'name': 'Complaint_Open', 'value': 5}, {'id': 'W_28_D', 'parent': 'D', 'name': 'W_28'}, {'id': 'Complaint_Close', 'parent': 'W_28_D', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_28_D', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_29_D', 'parent': 'D', 'name': 'W_29'}, {'id': 'Complaint_Close', 'parent': 'W_29_D', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_29_D', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_N_D', 'parent': 'D', 'name': 'W_N'}, {'id': 'Complaint_Close', 'parent': 'W_N_D', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_N_D', 'name': 'Complaint_Open', 'value': 29}, {'id': 'E', 'parent': '', 'name': 'E'}, {'id': 'W_3_E', 'parent': 'E', 'name': 'W_3'}, {'id': 'Complaint_Close', 'parent': 'W_3_E', 'name': 'Complaint_Close', 'value': 3}, {'id': 'Complaint_Open', 'parent': 'W_3_E', 'name': 'Complaint_Open', 'value': 2}, {'id': 'W_4_E', 'parent': 'E', 'name': 'W_4'}, {'id': 'Complaint_Close', 'parent': 'W_4_E', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_4_E', 'name': 'Complaint_Open', 'value': 5}, {'id': 'W_5_E', 'parent': 'E', 'name': 'W_5'}, {'id': 'Complaint_Close', 'parent': 'W_5_E', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_5_E', 'name': 'Complaint_Open', 'value': 3}, {'id': 'W_7_E', 'parent': 'E', 'name': 'W_7'}, {'id': 'Complaint_Close', 'parent': 'W_7_E', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_7_E', 'name': 'Complaint_Open', 'value': 12}, {'id': 'W_N_E', 'parent': 'E', 'name': 'W_N'}, {'id': 'Complaint_Close', 'parent': 'W_N_E', 'name': 'Complaint_Close', 'value': 5}, {'id': 'Complaint_Open', 'parent': 'W_N_E', 'name': 'Complaint_Open', 'value': 26}, {'id': 'F', 'parent': '', 'name': 'F'}, {'id': 'W_1_F', 'parent': 'F', 'name': 'W_1'}, {'id': 'Complaint_Close', 'parent': 'W_1_F', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_1_F', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_11_F', 'parent': 'F', 'name': 'W_11'}, {'id': 'Complaint_Close', 'parent': 'W_11_F', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_11_F', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_12_F', 'parent': 'F', 'name': 'W_12'}, {'id': 'Complaint_Close', 'parent': 'W_12_F', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_12_F', 'name': 'Complaint_Open', 'value': 1}, {'id': 'W_13_F', 'parent': 'F', 'name': 'W_13'}, {'id': 'Complaint_Close', 'parent': 'W_13_F', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_13_F', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_N_F', 'parent': 'F', 'name': 'W_N'}, {'id': 'Complaint_Close', 'parent': 'W_N_F', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_N_F', 'name': 'Complaint_Open', 'value': 1}, {'id': 'G', 'parent': '', 'name': 'G'}, {'id': 'W_21_G', 'parent': 'G', 'name': 'W_21'}, {'id': 'Complaint_Close', 'parent': 'W_21_G', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_21_G', 'name': 'Complaint_Open', 'value': 2}, {'id': 'W_23_G', 'parent': 'G', 'name': 'W_23'}, {'id': 'Complaint_Close', 'parent': 'W_23_G', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_23_G', 'name': 'Complaint_Open', 'value': 5}, {'id': 'W_24_G', 'parent': 'G', 'name': 'W_24'}, {'id': 'Complaint_Close', 'parent': 'W_24_G', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_24_G', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_27_G', 'parent': 'G', 'name': 'W_27'}, {'id': 'Complaint_Close', 'parent': 'W_27_G', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_27_G', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_N_G', 'parent': 'G', 'name': 'W_N'}, {'id': 'Complaint_Close', 'parent': 'W_N_G', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_N_G', 'name': 'Complaint_Open', 'value': 9},{'id': 'H', 'parent': '', 'name': 'H'}, {'id': 'W_20_H', 'parent': 'H', 'name': 'W_20'}, {'id': 'Complaint_Close', 'parent': 'W_20_H', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_20_H', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_30_H', 'parent': 'H', 'name': 'W_30'}, {'id': 'Complaint_Close', 'parent': 'W_30_H', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_30_H', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_31_H', 'parent': 'H', 'name': 'W_31'}, {'id': 'Complaint_Close', 'parent': 'W_31_H', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_31_H', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_32_H', 'parent': 'H', 'name': 'W_32'}, {'id': 'Complaint_Close', 'parent': 'W_32_H', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_32_H', 'name': 'Complaint_Open', 'value': 0}, {'id': 'W_N_H', 'parent': 'H', 'name': 'W_N'}, {'id': 'Complaint_Close', 'parent': 'W_N_H', 'name': 'Complaint_Close', 'value': 0}, {'id': 'Complaint_Open', 'parent': 'W_N_H', 'name': 'Complaint_Open', 'value': 0}]
 




function SunburstS() {
    const data = []
    var state = ''
    useEffect(() => {
        sdata.map((item) => {
            if ( item.name === 'A' || item.name==='A') {
                state = "#e76de7"
            }
            if (item.parent === 'B' || item.name === 'B') {
                state = "teal"
            }
            if (item.parent === 'C' || item.name === 'C') {
                state = "#65659c"
            }
            if (item.parent === 'D' || item.name === 'D') {
                state = "#7b4a4a"
            }
            if (item.parent === 'E' || item.name === 'E') {
                state = "orange"
            }
            if (item.parent === 'F' || item.name === 'F') {
                state = "#f06c82"
            }
            if (item.parent === 'G' || item.name === 'G') {
                state = "#c8e13d"
            }
            if (item.parent === 'H' || item.name === 'H') {
                state = "#34e6ce"
            }
            data.push({
                id: `${item.id}`,
                parent: `${item.parent}`,
                name: item.name,
                value: item.value,
                color:state
            })
        })


    }, [])

    console.log(data);
    // console.log(sdata);
    let options = {
        chart:{
            // zoomType: 'xy',
            backgroundColor: '#263238',
            // spacing: 40,
            type: "sunburst",
            // borderRadius: 16,
            // height:"600px"
            height:"250px",
            
        },
        title: {
            text:"",
            // text: "Classification of Complaints",
            // color:"white",
        },
        credits:{
            enabled:false
        },
        series: [
            
            {
                type: "sunburst",
                data: data,
                // colorByPoint: true,
                allowDrillToNode: true,
                // background: '#263238',
                backgroundColor: '#081a36',
                spacing: 40,
                borderRadius: 16,
                cursor: "pointer",
                drilldown: {
                    theme:{
                        style:{
                            color:"red"
                        },
                    breadcrumbs: {
                        showFullPath: false,
                       
                            color:"red"
                        
                    },}},
                drillUpButton: {
                    text: "",
                   theme:{
                    style:{
                        color:"red"
                    }
                   }
               },
                dataLabels: {
                    borderWidth: 0,
                    // filter: { property: "innerArcLength", operator: ">", value: 16 },
                    style: { textShadow: false, textOutline: null, color: "contrast" }
                },
                levels: [
                    {
                        level: 1,
                        levelIsConstant: false,
                        // dataLabels: {
                        //     filter: { property: "outerArcLength", operator: ">", value: 64 }
                        // },
                        colorByPoint: true
                    },
                    { level: 2, colorVariation: { key: "brightness", to: -0.3 } },
                    { level: 3, colorVariation: { key: "brightness", to: -0.3 } },
                    { level: 4, colorVariation: { key: "brightness", to: -0.3 } },
                    { level: 5, colorVariation: { key: "brightness", to: -0.3 } }
                ]
            }
        ]
    };

    return (
        <div style={{ width: "100%" }}>
            {/* <p>Classification of complaints across zones and month</p> */}
            <HighchartsReact
                // constructorType={"chart"}
                highcharts={Highcharts}
                options={options}
            />
        </div>
    );
}


export default SunburstS
