import React, { useEffect, useState } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import highchartsDumbbell from "highcharts/modules/dumbbell";
import HC_more from "highcharts/highcharts-more";
import { ClosedPercentageData } from "./dmmydata";
import styles from './Solid.module.css'
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
require('highcharts/modules/annotations')(Highcharts);


HC_more(Highcharts);


const ClosedPercentage = () => {
    var Complaint_Close = []
    var Percentage_of_closed_Complaints = []
    var Total = []
    var min = null;
    var max = null;
    var zero = null;

    ClosedPercentageData.map((item) => {
        Complaint_Close.push(item.Complaint_Close)
        Percentage_of_closed_Complaints.push(item["Percentage of closed complaints"])
        Total.push(item.Total)

    })
    var xMax = Math.max.apply(null, ClosedPercentageData.map(function (o) { return o["Percentage of closed complaints"] }));
    var maxXObject = ClosedPercentageData.filter(function (o) { return o["Percentage of closed complaints"] === xMax; });
    var ExcludeZero = ClosedPercentageData.filter((item) => item["Percentage of closed complaints"] != 0)
    var xMin = Math.min.apply(null, ExcludeZero.map(function (o) { return o["Percentage of closed complaints"] }));
    var minObject = ClosedPercentageData.filter(function (o) { return o["Percentage of closed complaints"] === xMin; });
    var zero = ClosedPercentageData.filter(function (o) { return o["Percentage of closed complaints"] === 0 });
    max = maxXObject
    min = minObject
    console.log("max" + JSON.stringify(maxXObject));
    const [chartOptions, setChartOptions] = useState({
        chart: {
            style: {
                fontFamily: "'Poppins', sans- serif",
                color: 'white'
            },
            type: "column",
            zoomType: 'xy',
            backgroundColor: '#263238',
            spacing: 40,
            borderRadius: 16,
            height:"250px",
        },
        title:
        {
            style: {
                color: 'white',
                font: 'bold 20px',
            },
            text: "",

        },
        subtitle: {
            text: "",
        },
        legend: {
            enabled: false
        },
        xAxis: {
            categories: ["A", "B", "C", "D", "E", "F", "G", "H"],
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "Zones",

            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        yAxis: {
            gridLineColor: "#2e384a",
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "Percentage",
                color: "white"
            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px Trebuchet MS, Verdana, sans-serif'
                }
            },
        },
        plotOptions: {
            series: {
                borderColor: 'none'
            }
        },
        series: [
            {
                name: "Percentage of Closed Complaints",
                data: Percentage_of_closed_Complaints,
                color: '#f44336',
                dataLabels: {
                    enabled: true,
                    rotation: 360,
                    color: '#FFFFFF',
                    y: 15, // 10 pixels down from the top
                    style: {
                        fontSize: '12px',
                        fontWeight: 'bold',
                        borderColor: "red",
                        textOutline: 0,

                    }
                }
            },

        ],
        responsive: {
            rules: [{
                condition: {
                    minHeight: 500
                },
                chartOptions: {
                    legend: {
                        symbolHeight: 24,
                        itemStyle: {
                            fontSize: '24px'
                        }
                    },
                    title: {
                        style: {
                            fontSize: '32px',

                        }
                    },
                    xAxis: {
                        title: {
                            style: {
                                fontSize: ' 16px'
                            },
                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                    yAxis: {

                        title: {
                            style: {
                                color: '#BBDEFB',
                                fontSize: ' 16px'
                            },

                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                }
            }]
        },
    });

    return (
        <div style={{ width: "100%" }}>
            <HighchartsReact highcharts={Highcharts} options={chartOptions} />
            {/* <div className={styles.chartDetails}>
                <div className={styles.elements}>
                    {max.map((item) => <span><span className={styles.highlight}>Zone {item.Zone}</span> reported highest complaints closing percentage <span className={styles.highlight}>({item["Percentage of closed complaints"]}%)</span></span>)}
                   
                </div>
                <div className={styles.elements}>
                <span>The  Zones{zero.map((item)=> <span className={styles.highlight}> {item.Zone}, </span> )} showed <span className={styles.highlight}>Zero</span> closing percentage of total complaints </span>
                </div>
            </div> */}
        </div>
    );
};


export default ClosedPercentage