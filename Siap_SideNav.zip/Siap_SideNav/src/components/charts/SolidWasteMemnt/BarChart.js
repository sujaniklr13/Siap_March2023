import React, { useEffect, useState } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import highchartsDumbbell from "highcharts/modules/dumbbell";
import HC_more from "highcharts/highcharts-more";
import { BarchartData } from "./dmmydata";
import styles from './Solid.module.css'
import moment from "moment";
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
require('highcharts/modules/annotations')(Highcharts);


HC_more(Highcharts);


const BarChart = () => {
    const [toDate, setToDate] = useState("2022-10-31")
    var max = null
    var min = null
    var zero = null
    var Complaint_Close = []
    var Complaint_Open = []
    var Complaint_Total = []
    var Complaint_CloseA = []
    var Complaint_OpenA = []
    var Complaint_TotalA = []
    var months = []
    var zones = []
    var monthsUnique = null


    BarchartData.map((data) => {
        months.push(data.DateTime)
        monthsUnique = [... new Set(months)]

    })
    const handleChangeEnd = (e) => {
        setToDate(e.target.value)
        const filterData = BarchartData.filter((item) => {
            return item.DateTime === e.target.value
        })
        console.log(filterData);
        var xMax = Math.max.apply(null, filterData.map(function (o) { return o["Total Complaints"]; }));
        var maxXObject = filterData.filter(function (o) { return o["Total Complaints"] === xMax; })[0];
        var ExcludeZero = filterData.filter((item) => item["Total Complaints"] != 0)
        var xMin = Math.min.apply(null, ExcludeZero.map(function (o) { return o["Total Complaints"] }));
        var minObject = filterData.filter(function (o) { return o["Total Complaints"] === xMin; })[0];
        var zeroObject = filterData.filter(function (o) { return o["Total Complaints"] === 0 });
        max = maxXObject
        min = minObject
        zero = zeroObject
        filterData.map((item) => {
            Complaint_CloseA.push({ y: item["Closed Complaints"] })
            Complaint_OpenA.push({ y: item["Open Complaints"] })
            Complaint_TotalA.push({ y: item["Total Complaints"] })
            zones.push(item.Zone)
        })
        setChartOptions({
            series: [
                {
                    name: "Complaint Close",
                    data: Complaint_CloseA,
                    color: '#e91e63',
                    dataLabels: {
                        enabled: true,
                        rotation: 360,
                        color: 'white',
                        y: 10, // 10 pixels down from the top
                        style: {
                            fontSize: '10px',
                            borderColor: "red",
                            textOutline: 0,

                        }
                    }
                },
                {
                    name: "Complaint Open",
                    data: Complaint_OpenA,
                    color: '#2196f3',
                    dataLabels: {
                        enabled: true,
                        rotation: 360,
                        color: 'white',
                        y: 10, // 10 pixels down from the top
                        style: {
                            fontSize: '10px',
                            // fontWeight: 'bold',
                            borderColor: "red",
                            textOutline: 0,

                        }
                    }
                },
                {
                    name: "Complaint Total",
                    data: Complaint_TotalA,
                    color: '#f44336',
                    dataLabels: {
                        enabled: true,
                        rotation: 360,
                        color: 'white',
                        y: 10, // 10 pixels down from the top
                        style: {
                            fontSize: '10px',
                            // fontWeight: 'bold',
                            borderColor: "red",
                            textOutline: 0,

                        }
                    }
                },

            ],
            xAxis: { categories: zones }
        })

    }

    const filterData = BarchartData.filter((item) => {
        return item.DateTime === toDate
    })
    console.log(filterData);
    var xMax = Math.max.apply(null, filterData.map(function (o) { return o["Total Complaints"]; }));
    var maxXObject = filterData.filter(function (o) { return o["Total Complaints"] === xMax; })[0];
    var ExcludeZero = filterData.filter((item) => item["Total Complaints"] != 0)
    var xMin = Math.min.apply(null, ExcludeZero.map(function (o) { return o["Total Complaints"] }));
    var minObject = filterData.filter(function (o) { return o["Total Complaints"] === xMin; })[0];
    var zeroObject = filterData.filter(function (o) { return o["Total Complaints"] === 0 });
    max = maxXObject
    min = minObject
    zero = zeroObject
    filterData.map((item) => {
        Complaint_Close.push({ y: item["Closed Complaints"] })
        Complaint_Open.push({ y: item["Open Complaints"] })
        Complaint_Total.push({ y: item["Total Complaints"] })
        zones.push(item.Zone)
    })

    const [chartOptions, setChartOptions] = useState({
        chart: {
            style: {
                fontFamily: "'Poppins', sans- serif",
                color: 'white'
            },
            type: "column",
            zoomType: 'xy',
            backgroundColor: '#263238',
            // spacing: 40,
            // borderRadius: 16
            height:"250px",
        },
        title: {
            style: {
                color: 'white',
                font: 'bold 20px',

            },
            text: "",
        },
        subtitle: {
            text: "",
        },
        legend: {
            itemStyle: {
                color: 'white',
                font: 'bold 20px',
            },
            enabled: true
        },
        xAxis: {
            categories: zones,
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "Zones",
                // color: "red"
            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        yAxis: {
            gridLineColor: "#2e384a",
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "No:of Complaints",

            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        plotOptions: {
            series: {
                borderColor: 'none'
            }
        },
        series: [
            {
                name: "Complaint Close",
                data: Complaint_Close,
                color: '#e91e63',
                dataLabels: {
                    enabled: true,
                    rotation: 360,
                    color: 'white',
                    y: 10, // 10 pixels down from the top
                    style: {
                        fontSize: '10px',
                        borderColor: "red",
                        textOutline: 0,

                    }
                }
            },
            {
                name: "Complaint Open",
                data: Complaint_Open,
                color: '#2196f3',
                dataLabels: {
                    enabled: true,
                    rotation: 360,
                    color: 'white',
                    y: 10, // 10 pixels down from the top
                    style: {
                        fontSize: '10px',
                        // fontWeight: 'bold',
                        borderColor: "red",
                        textOutline: 0,

                    }
                }
            },
            {
                name: "Complaint Total",
                data: Complaint_Total,
                color: '#f44336',
                dataLabels: {
                    enabled: true,
                    rotation: 360,
                    color: 'white',
                    y: 10, // 10 pixels down from the top
                    style: {
                        fontSize: '10px',
                        // fontWeight: 'bold',
                        borderColor: "red",
                        textOutline: 0,

                    }
                }
            },

        ],
        responsive: {
            rules: [{
                condition: {
                    minHeight: 500
                },
                chartOptions: {
                    legend: {
                        symbolHeight: 24,
                        itemStyle: {
                            fontSize: '24px'
                        }
                    },
                    title: {
                        style: {
                            fontSize: '32px',

                        }
                    },
                    xAxis: {
                        title: {
                            style: {
                                fontSize: ' 16px'
                            },
                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                    yAxis: {

                        title: {
                            style: {
                                color: '#BBDEFB',
                                fontSize: ' 16px'
                            },

                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                }
            }]
        },
    });

    return (
        <div style={{ width: "100%" }}>
            <div id="option-container">
            <span id="option-text">Month : </span> <select value={toDate} onChange={handleChangeEnd} >
                {monthsUnique.map((option) => (
                    <option key={option} value={option} >
                        {moment(new Date(option)).format('MMMM YYYY')}
                    </option>
                ))}
            </select>
            </div>
            <HighchartsReact highcharts={Highcharts} options={chartOptions} />
            {/* <div className={styles.chartDetails}>
                <div className={styles.elements}>
                    <span><span className={styles.highlight} style={{ color: "" }}>Zone {max?.Zone}</span> reported <span className={styles.highlight}>highest</span> number of complaints <span className={styles.highlight}>({max?.["Total Complaints"]})</span></span>
                </div>
                <div className={styles.elements}>
                    <span><span className={styles.highlight}>Zone {min?.Zone}</span> reported the <span className={styles.highlight}>least</span> number of complaints <span className={styles.highlight}>({min?.["Total Complaints"]})</span></span>
                </div>
                <div className={styles.elements}>
                    <span>{zero?.map((item) => <span className={styles.highlight}>Zone {item.Zone}, </span>)} reported no complaints during the period considered</span>
                   
                </div>
            </div> */}
        </div>
    );
};


export default BarChart