import React, { useEffect, useState } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import highchartsDumbbell from "highcharts/modules/dumbbell";
import HC_more from "highcharts/highcharts-more";
import { DumbbellData } from "./dmmydata";
import moment from "moment";
import styles from './Solid.module.css'
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
require('highcharts/modules/annotations')(Highcharts);

HC_more(Highcharts);
highchartsDumbbell(Highcharts);
const data=[{"Zone":"A","March-2022":6.0,"October-2022":10.0},{"Zone":"B","March-2022":6.0,"October-2022":18.0},{"Zone":"C","March-2022":8.0,"October-2022":15.0},{"Zone":"D","March-2022":50.0,"October-2022":64.0},{"Zone":"E","March-2022":36.0,"October-2022":58.0},{"Zone":"F","March-2022":2.0,"October-2022":2.0},{"Zone":"G","March-2022":0.0,"October-2022":16.0},{"Zone":"H","March-2022":0.0,"October-2022":0.0}]
const Dumbbell = () => {
    var months = []
    var monthsUnique = null
    const [fromDate, setFromDate] = useState(null)
    const [toDate, setToDate] = useState(null)
    var Dump = []
    DumbbellData.map((item) => {
        months.push(item.DateTime)
        monthsUnique = [... new Set(months)]

    })
    const handleChangeStart = (e) => {
        setFromDate(e.target.value)
    }
    const handleChangeEnd = (e) => {
        setToDate(e.target.value)
    }
   
        data.map((item) => {
            Dump.push({ name: item.Zone, low: item["March-2022"], high: item["October-2022"] })
        })
   
    
    const [chartOptions, setChartOptions] = useState({
        chart: {
            style: {
                fontFamily: "'Poppins', sans- serif",
                color: 'white'
            },
            type: "dumbbell",
            inverted: true,
            zoomType: 'xy',
            backgroundColor: '#263238',
            // spacing: 40,
            // borderRadius: 16,
            height:"250px",
        },

        legend: {
            enabled: true,
            itemStyle: {
                color: "white"
            }
        },

        subtitle: {
            style: {
                color: '#BBDEFB',
                font: ' 12px'
            },
            text: "March & October"
        },

        // title: {
        //     style: {
        //         color: 'white',
        //         font: '5px',

        //     },
         
        //     text: "Complaint Comparison"
        // },

        tooltip: {
            shared: true
        },

        xAxis: {
            type: "category",
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "Zones"
            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },

        yAxis: {
            gridLineColor: "#2e384a",
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "Values"
            },
            labels: {
                format: '{value}',
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        plotOptions: {
            dumbbell: {
                grouping: false
            }
        },
        tooltip: {
            shared: true,
            useHTML: true,
            formatter: function () {
             
                return '<b>' + this.points[0].point.name + '</b> <br/> <span class="blueDot" >March : ' + this.points[0].point.low + ' </span>' + '<br/><span  class="redDot" >October: ' + this.points[0].point.high + ' </span>';
            }
        },
        series: [
            {
                name: "March",
                data: Dump,
                color: '#f44336',
                connectorColor: "#ffee58",
                lowColor: "#f44336",
                marker: {
                    fillColor: "#2196f3"
                },
            },
            {
                name: "October",
                color: "#2196f3"
            }
        ],
        responsive: {
            rules: [{
                condition: {
                    // minHeight: 500
                },
                chartOptions: {
                    legend: {
                        symbolHeight: 24,
                        itemStyle: {
                            fontSize: '24px'
                        }
                    },
                    title: {
                        style: {
                            fontSize: '32px',

                        }
                    },
                    xAxis: {
                        title: {
                            style: {
                                fontSize: ' 16px'
                            },
                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                    yAxis: {

                        title: {
                            style: {
                                color: '#BBDEFB',
                                fontSize: ' 16px'
                            },

                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                }
            }]
        },
    });


    return (
        <div style={{ width: "100%" }}>
            {/* <span>From: </span> <select value={fromDate} onChange={handleChangeStart} >
                {monthsUnique.map((option) => (
                    <option key={option} value={option} >
                        {moment(new Date(option)).format('MMMM YYYY')}
                    </option>
                ))}
            </select>
            <span>To: </span> <select value={toDate} onChange={handleChangeEnd} >
                {monthsUnique.map((option) => (
                    <option key={option} value={option} >
                        {moment(new Date(option)).format('MMMM YYYY')}
                    </option>
                ))}
            </select> */}
            <HighchartsReact highcharts={Highcharts} options={chartOptions} />
            {/* <div className={styles.chartDetails}>
                    <div className={styles.elements}>
                        <span><span className={styles.highlight}>Highest</span> number of complaints were reported in <span className={styles.highlight}>ZoneE (22)</span>, followed by <span className={styles.highlight}>ZoneG (16)</span></span>
                    </div>
                    <div className={styles.elements}>
                        <span><span className={styles.highlight}>Least</span> number of complaints were reported at <span className={styles.highlight}>Zones F & H (0 complaints) </span> </span>
                    </div>
                </div> */}
        </div>
    );
};


export default Dumbbell