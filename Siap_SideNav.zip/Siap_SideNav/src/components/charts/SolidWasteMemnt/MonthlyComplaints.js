import React, { useEffect, useState } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import highchartsDumbbell from "highcharts/modules/dumbbell";
import HC_more from "highcharts/highcharts-more";
import styles from './Solid.module.css'
import { ClosedPercentageData, MonthlycomplaintsData } from "./dmmydata";
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
require('highcharts/modules/annotations')(Highcharts);

HC_more(Highcharts);

const MonthlyComplaints = () => {
    var No_Of_Complaints = []
    var Month = []
    var max = null;
    var min = null;

    MonthlycomplaintsData.map((item) => {
        No_Of_Complaints.push(item["Number of Complaints"])
        Month.push(item["Month & Year"])
    });

    var xMax = Math.max.apply(null, MonthlycomplaintsData.map(function (o) { return o["Number of Complaints"]; }));
    var maxXObject = MonthlycomplaintsData.filter(function (o) { return o["Number of Complaints"] === xMax; });
    var ExcludeZero = MonthlycomplaintsData.filter((item) => item["Number of Complaints"] != 0)
    var xMin = Math.min.apply(null, ExcludeZero.map(function (o) { return o["Number of Complaints"] }));
    var minObject = MonthlycomplaintsData.filter(function (o) { return o["Number of Complaints"] === xMin; });
   
    max = maxXObject
    min = minObject

    const [chartOptions, setChartOptions] = useState({
        chart: {
            type: "column",
            zoomType: 'xy',
            backgroundColor: '#263238',
            // spacing: 40,
            // borderRadius: 16
            height:"250px",
        },
        title: {
            style: {
                color: 'white',
                font: 'bold 20px',

            },
            text: "",
        },
        subtitle: {
            text: "",
        },
        legend: {
            enabled: false
        },
        xAxis: {
            categories: Month,
            title: {
                text: "Month & Year",
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px'
                }
            },
        },
        yAxis: {
            gridLineColor: "#2e384a",
            title: {
                style: {
                    color: '#BBDEFB',
                    font: ' 12px'
                },
                text: "No : Of Complaints",
            },
            labels: {
                style: {
                    color: 'white',
                    font: '11px Trebuchet MS, Verdana, sans-serif'
                }
            },
        },
        plotOptions: {
            series: {
                borderColor: 'none'
            }
        },
        series: [
            {
                name: " No Of Complaints",
                data: No_Of_Complaints,
                color: '#f44336',
                dataLabels: {
                    enabled: true,
                    rotation: 360,
                    color: '#FFFFFF',
                    y: 15, // 10 pixels down from the top
                    style: {
                        fontSize: '12px',
                        fontWeight: 'bold',
                        borderColor: "red",
                        textOutline: 0,

                    }
                }
            },


        ],
        responsive: {
            rules: [{
                condition: {
                    minHeight: 500
                },
                chartOptions: {
                    legend: {
                        symbolHeight: 24,
                        itemStyle: {
                            fontSize: '24px'
                        }
                    },
                    title: {
                        style: {
                            fontSize: '32px',

                        }
                    },
                    xAxis: {
                        title: {
                            style: {
                                fontSize: ' 16px'
                            },
                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                    yAxis: {

                        title: {
                            style: {
                                color: '#BBDEFB',
                                fontSize: ' 16px'
                            },

                        },
                        labels: {
                            style: {
                                fontSize: '16px'
                            }
                        },
                    },
                }
            }]
        },
    });

    return (
        <div style={{ width: "100%" }}>
            <HighchartsReact highcharts={Highcharts} options={chartOptions} updateArgs={[true]} />
            {/* <div className={styles.chartDetails}>
                <div className={styles.elements}>

                    <span>The <span className={styles.highlight}>highest</span> number of complaints were reported during the months of {max.map((item)=><span className={styles.highlight}>{item["Month & Year"]}, ({item["Number of Complaints"]})</span>)}
                    </span>
                </div>
                <div className={styles.elements}>
                    <span> The <span className={styles.highlight}>lowest</span>number of complaints were reported during {min.map((item)=><span className={styles.highlight}>{item["Month & Year"]} ({item["Number of Complaints"]})</span>)}</span>
                </div>
            </div> */}
        </div>
    );
};


export default MonthlyComplaints