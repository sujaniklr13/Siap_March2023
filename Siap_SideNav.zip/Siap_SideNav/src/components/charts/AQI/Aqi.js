import React from 'react'

function Aqi() {
  return (
    <div className="graph-container">
    <h1>  this is under development AQI
       </h1>
       </div>
  )
}

export default Aqi