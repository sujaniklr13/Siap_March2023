import {  useParams } from "react-router-dom";
import LineChartTraffic from "./LineChartTraffic";


function GraphView() {
    const {graphView} = useParams();
    console.log('a',graphView)
    const renderChart = () => {
        switch(graphView) {
          case 'classificationOfComplains':
            return <LineChartTraffic />;
        }
      }
    return (
        <div style={{paddingTop: "100px"}}>{renderChart()}</div>
    );
}

export default GraphView;