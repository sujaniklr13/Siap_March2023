import React, { useEffect, useState } from "react";
import L from "leaflet";

import icon from "leaflet/dist/images/marker-icon.png";
import iconShadow from "leaflet/dist/images/marker-shadow.png";

import "leaflet/dist/leaflet.css";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "./MyMap.css";

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow
});

const iconUrl = [
  "https://img.icons8.com/flat-round/64/null/recycle-sign--v1.png",
  "https://img.icons8.com/flat-round/64/null/recycle-sign--v1.png",
  "https://img.icons8.com/flat-round/64/null/recycle-sign--v1.png",
  "https://img.icons8.com/flat-round/64/null/recycle-sign--v1.png",
  "https://img.icons8.com/flat-round/64/null/recycle-sign--v1.png",
  "https://img.icons8.com/flat-round/64/null/recycle-sign--v1.png",
  "https://img.icons8.com/flat-round/64/null/recycle-sign--v1.png",
  "https://img.icons8.com/flat-round/64/null/recycle-sign--v1.png"
];

L.Marker.prototype.options.icon = DefaultIcon;

function MyMap(props) {
  const [mapData, setMapData] = useState([]);
  const getMapData = async () => {
    const getJson = await fetch("final_data.json", {});

    let finalJSON = await getJson.json();

    if (finalJSON) {
      setMapData(finalJSON.data);
    }
  };
  const position1 = [18.6316143143, 73.8270092784]; //BENGALURU
  
  // const myIcon1 = new L.Icon({
  //   iconUrl:
  //     "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png",
  //   shadowUrl:
  //     "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
  //   iconSize: [25, 41],
  //   iconAnchor: [12, 41],
  //   popupAnchor: [1, -34],
  //   shadowSize: [41, 41]
  // });

  // const myIcon2 = new L.Icon({
  //   iconUrl:
  //     "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png",
  //   shadowUrl:
  //     "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
  //   iconSize: [25, 41],
  //   iconAnchor: [12, 41],
  //   popupAnchor: [1, -34],
  //   shadowSize: [41, 41]
  // });

  const fetchDb = (pos, loc) => {
    //  debugger

    console.log("pos=", pos, loc);
  };

  useEffect(() => {
    getMapData();
  }, []);
  console.log(mapData, "mapData");
  return (
    <div className="map-conatiner">
      <MapContainer center={position1} zoom={11.5} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.osm.org/{z}/{x}/{y}.png"
        />
        {mapData.map((val, index) => (
          <Marker
            key={val.Location + index}
            eventHandlers={{
              click: (e) => {
                fetchDb(val.Location, val.Location);
              }
            }}
            position={[val.Latitude, val.Longitude]}
            icon={
              new L.Icon({
                iconUrl:
                  "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png",

                shadowUrl:
                  "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                shadowSize: [41, 41]
              })
            }
            pathOptions={{ color: "green", fillColor: "green" }}
          >
            <Popup>{val.Location}</Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

export default MyMap;
