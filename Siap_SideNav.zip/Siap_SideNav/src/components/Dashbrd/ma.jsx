import React, { useEffect, useState } from "react";
import L from "leaflet";

import icon from "leaflet/dist/images/marker-icon.png";
import iconShadow from "leaflet/dist/images/marker-shadow.png";

import "leaflet/dist/leaflet.css";
import { MapContainer,ZoomControl, TileLayer, Marker, Popup } from "react-leaflet";
import "./MyMap.css";
let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow
});

L.Marker.prototype.options.icon = DefaultIcon;

function MyMap(props) {
  const position = [12.972442, 77.540641];

  const position1 = [12.972442, 77.540641]; //BENGALURU
  const position2 = [12.964462, 77.574643]; //SINGAPORE
  const position3 = [12.952342, 77.580643]; //WASHINGTON
  const position4 = [12.962742, 77.580643]; //london
  const position5 = [12.932442, 77.571443]; //BEIJING
  const position6 = [12.942341, 77.424643]; //TOKYO
  const position7 = [12.765433, 77.654332]; //SYDNEY

  const myIcon1 = new L.Icon({
    iconUrl:
      "https://img.icons8.com/external-others-inmotus-design/67/null/external-Recycle-rounded-square-icons-others-inmotus-design.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });

  const myIcon2 = new L.Icon({
    iconUrl:
      "https://img.icons8.com/external-others-inmotus-design/67/null/external-Recycle-rounded-square-icons-others-inmotus-design.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
  const myIcon3 = new L.Icon({
    iconUrl:
      "https://img.icons8.com/external-others-inmotus-design/67/null/external-Recycle-rounded-square-icons-others-inmotus-design.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
  const myIcon4 = new L.Icon({
    iconUrl:
      "https://img.icons8.com/external-others-inmotus-design/67/null/external-Recycle-rounded-square-icons-others-inmotus-design.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
  const myIcon5 = new L.Icon({
    iconUrl:
      "https://img.icons8.com/external-others-inmotus-design/67/null/external-Recycle-rounded-square-icons-others-inmotus-design.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
  const myIcon6 = new L.Icon({
    iconUrl:
      "https://img.icons8.com/external-others-inmotus-design/67/null/external-Recycle-rounded-square-icons-others-inmotus-design.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
  const myIcon7 = new L.Icon({
    iconUrl:
      "https://img.icons8.com/external-others-inmotus-design/67/null/external-Recycle-rounded-square-icons-others-inmotus-design.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
  const fetchDb = (pos, loc) => {
    //  debugger
    props.setloc(loc);
    console.log("pos=", pos, loc);
  };
  return (
    <div className="map-conatiner">
      <MapContainer center={position} zoom={10} scrollWheelZoom={false} zoomControl={false}>
        <TileLayer
          attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.osm.org/{z}/{x}/{y}.png"
        />
         <ZoomControl position="bottomright" />
        <Marker
          eventHandlers={{
            click: (e) => {
              fetchDb(position1, "BENGALURU");
            }
          }}
          position={position1}
          icon={myIcon1}
          pathOptions={{ color: "green", fillColor: "green" }}
        >
          <Popup>BENGALURU</Popup>
        </Marker>
        <Marker
          eventHandlers={{
            click: (e) => {
              fetchDb(position1, "SINGAPORE");
            }
          }}
          position={position2}
          icon={myIcon2}
        >
          <Popup>SINGAPORE</Popup>
        </Marker>
        <Marker
          eventHandlers={{
            click: (e) => {
              fetchDb(position1, "WASHINGTON");
            }
          }}
          position={position3}
          icon={myIcon3}
        >
          <Popup>WASHINGTON</Popup>
        </Marker>
        <Marker
          eventHandlers={{
            click: (e) => {
              fetchDb(position1, "London");
            }
          }}
          position={position4}
          icon={myIcon4}
        >
          <Popup>London</Popup>
        </Marker>
        <Marker
          eventHandlers={{
            click: (e) => {
              fetchDb(position1, "BEIJING");
            }
          }}
          position={position5}
          icon={myIcon5}
        >
          <Popup>BEIJING</Popup>
        </Marker>
        <Marker
          eventHandlers={{
            click: (e) => {
              fetchDb(position1, "TOKYO");
            }
          }}
          position={position6}
          icon={myIcon6}
        >
          <Popup>TOKYO</Popup>
        </Marker>
        {/* onClick={fetchDb(position7,"SYDNEY")} */}
        <Marker
          eventHandlers={{
            click: (e) => {
              fetchDb(position1, "SYDNEY");
            }
          }}
          position={position7}
          icon={myIcon7}
        >
          <Popup>SYDNEY</Popup>
        </Marker>
      </MapContainer>
    </div>
  );
}

export default MyMap;
//npm install --save-exact react-leaflet@3.1.0
// import React from "react";

// function MyMap() {

//   return (
//     <h1>Mapp</h1>

//   );
// }

// export default MyMap;
