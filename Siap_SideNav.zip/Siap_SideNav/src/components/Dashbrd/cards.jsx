import './cards.css'
import LineChartTrafficMonth from '../charts/SolidWasteMemnt/LineChartTraffic'
const Cards = () => {
    const layer1=document.querySelector(".layer1")
    layer1.addEventListener('click', function() {
        layer1.classList.add('clicked');
      });
    return (
        <div className="cards">
            <div className='month' >
            <a className='m-0 view-more' href="/Trafficdata" ></a>
                        <img className='greater-icon' src="./images/lessthan.svg" alt="" />
            </div>

            <div className="solid-waste-management carddim " >
                <div className='layer1'>
                    <div className='logo'>
                        <img src="./images/solid-waste-management.png" alt="" />
                        <h3 className='m-0'>Solid Waste Management</h3>
                    </div>
                    <div className='view-more'>
                        <a className='m-0' href="/SolidWastemanagment" >view more</a>
                        <img className='greater-icon' src="./images/greater.png" alt="" />
                    </div>
                </div>

                <div style={{marginBottom:"11px"}} className='layer2'>
                    Total Complaints Recieved
                </div>
                <hr />
                <div>

                    <div style={{marginTop:"11px",marginBottom:"7px"}} className='layer3'>
                        <div className='month'>
                            This Month
                        </div>
                        <div className='date-heads d-flex flex-column align-items-center'>
                            <div className='date1'>14</div>
                            <div className='heads'>Till</div>
                        </div>

                        <div className='zone-heads d-flex flex-column align-items-center'>
                            <div className='zone1'>
                                <h3>D</h3>
                                <p>Zone</p>
                            </div>
                            <div className='heads'>Most</div>
                        </div>

                        <div className='zone-heads d-flex flex-column align-items-center'>
                            <div className='zone2'>
                                <h3>F</h3>
                                <p>Zone</p>
                            </div>

                            <div className='heads'>
                                Least
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div style={{marginTop:"9px"}} className="layer4">
                        <div className='month'>Last Month</div>
                        <div className='date2'>29</div>
                        <div className='arrow'>
                            <div>
                                <img src="./images/uparrow.png" alt="" />
                            </div>
                            <div>
                                <h2 className='m-0'>7% Increase</h2>
                                <p className='m-0'>From Previous month</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="cctv carddim">
                <div className='row1'>
                    <div className='logo'>
                        <img src="./images/cctv.png" alt="" />
                        <h3 className='m-0'>CCTV</h3>
                    </div>
                    <div className='view-more'>
                        <a className='m-0' href="/CcTv" >view more</a>
                        <img className='greater-icon' src="./images/greater.png" alt="" />
                    </div>
                </div>

                <div style={{marginTop:"10.5px"}} className='row2'>
                    CCTV Status
                </div>

                <div className='row3'>
                    <div className='cctv-zone'>
                        Zone
                    </div>

                    <div className='zone-list'>
                        <div>A</div>
                        <div>B</div>
                        <div>C</div>
                        <div>D</div>
                        <div>E</div>
                        <div>F</div>
                        <div>G</div>
                        <div>H</div>
                    </div>
                </div>
                <hr />
                <div className='row4'>
                    <div className='active'>
                        <img src="./images/s-cctv.png" alt="" />
                        <div className='cctv-zone'>Active</div>
                    </div>

                    <div className='active-list'>
                        <div>8</div>
                        <div>9</div>
                        <div>7</div>
                        <div>13</div>
                        <div>6</div>
                        <div>11</div>
                        <div>10</div>
                        <div>11</div>
                    </div>
                </div>
                <hr />
                <div className='row5'>
                    <div className='inactive'>
                        <img src="./images/is-cctv.png" alt="" />
                        <div className='cctv-zone'>Active</div>
                    </div>

                    <div className='inactive-list'>
                        <div>8</div>
                        <div>9</div>
                        <div>7</div>
                        <div>13</div>
                        <div>6</div>
                        <div>11</div>
                        <div>10</div>
                        <div>11</div>
                    </div>
                </div>
            </div>

            <div className='AQI carddim'>
                <div className='level1'>
                    <div className='logo'>
                        <img src="./images/leaf.png" alt="" />
                        <h3 className='m-0'>AQI</h3>
                    </div>
                    <div className='view-more'>
                        <a className='m-0'href="/Aqi">view more</a>
                        <img className='greater-icon' src="./images/greater.png" alt="" />
                    </div>
                </div>
                <div className='level2'>
                    AQI in Different Zones
                </div>
                <div className='level3'>
                    <div className='layout'>
                        <div className='boxes' style={{ background: "#00B050", }}>A</div>
                        <div className='boxes' style={{ background: "#92D050", }}>B</div>
                        <div className='boxes' style={{ background: "#FFFF00", }}>C</div>
                        <div className='boxes' style={{ background: "#92D050", }}>D</div>
                        <div className='boxes' style={{ background: "#FFFF00", }}>E</div>
                        <div className='boxes' style={{ background: "#FF6500", }}>F</div>
                        <div className='boxes' style={{ background: "#FF6500", }}>G</div>
                        <div className='boxes' style={{ background: "#FF0000", }}>H</div>
                        <div className='boxes' style={{ background: "#37474F", }}></div>
                    </div>

                    <div className='color-code'>
                        <div className='cir-des'>
                            <div className='circle' style={{ background: "#00B050" }}></div>
                            <p className='description'>Good</p>
                        </div>

                        <div className='cir-des'>
                            <div className='circle' style={{ background: " #92D050" }}></div>
                            <p className='description'>Satisfactory</p>
                        </div>

                        <div className='cir-des'>
                            <div className='circle' style={{ background: "#FFFF00" }}></div>
                            <p className='description'>Moderate</p>
                        </div>

                        <div className='cir-des'>
                            <div className='circle' style={{ background: "#FF6500" }}></div>
                            <p className='description'>Poor</p>
                        </div>

                        <div className='cir-des'>
                            <div className='circle' style={{ background: "#FF0000" }}></div>
                            <p className='description'>Severe</p>
                        </div>
                    </div>

                </div>
            </div>

            <div className='traffic carddim'>
                <div className='heir1'>
                    <div className='logo'>
                        <img src="./images/traffic.png" alt="" />
                        <h3 className='m-0'>Traffic</h3>
                    </div>
                    <div className='view-more'>
                        <a className='m-0' href="/Trafficdata">view more</a>
                        <img className='greater-icon' src="./images/greater.png" alt="" />
                    </div>
                </div>

                <div className='heir2'>
                    Traffic Congestion
                </div>
                <div className='level3'>
                {/* <LineChartTrafficMonth/> */}
                </div>
            </div>

            <div className='month ' >
            <a className='m-0' href="/SolidWastemanagment" ></a>
                        <img className='greater-icon' src="./images/greater.png" alt="" />
            </div>
        </div>
    );
}

export default Cards;