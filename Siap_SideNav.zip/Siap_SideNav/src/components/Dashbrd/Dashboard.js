import React from 'react'
// import MyMap from './MyMap'
import MyMap from './ma'
import Cards from './cards'
function Dashboard() {
  return (
    <div>
      <MyMap />
        <Cards style="width:100%" />
    </div>
  )
}

export default Dashboard