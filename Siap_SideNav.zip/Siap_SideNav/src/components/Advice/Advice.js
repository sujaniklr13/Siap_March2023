import React from 'react'
import CardAdvice from './CardAdvice'
import CardAdvice2 from './CardAdvice2'
function Advice() {
  return (
    <div className="graph-container">
        <CardAdvice 
         IssueDescrip="Analysis show that feed from CCTV of ID 'CC/12/234' is inconsistant."
         RecomendationDescrip ="Manual trouble shooting by Technician."
               />
              
     </div>
        
       
    
  )
}

export default Advice