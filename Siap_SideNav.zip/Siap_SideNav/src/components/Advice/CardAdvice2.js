import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

export default function CardAdvice2 ({screen,IssueDescrip, RecomendationDescrip }) {
  return (
    <div className={screen}>
    <Card  style={{ width: '18rem' }} >
      {/* <Card.Header>Danger</Card.Header> */}
      <Card.Body>
      <Card.Title>Issue
      <img src="./images/solid-waste-management.png" alt="" />

      </Card.Title>
        <Card.Text>
        {IssueDescrip}
        </Card.Text>
        <Card.Title>Recomendation</Card.Title>
        <Card.Text>{RecomendationDescrip} 
        </Card.Text>
        <div className='but'>
        <Button >Ignore</Button>
        <Button variant="danger">View</Button>
        </div>
        
      </Card.Body>
    
    </Card>
    </div>
  );
}

 