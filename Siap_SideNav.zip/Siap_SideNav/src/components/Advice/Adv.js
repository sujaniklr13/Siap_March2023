import React from "react";
import CardAdvice from './CardAdvice'
import AdvSelect from './AdvSelect'
import DynamicChart from '../charts/SolidWasteMemnt/DynamicChart';
import SunburstS from '../charts/SolidWasteMemnt/SunburstS'

const Adv = () => {

    return (
      <>
        <div className="graph-container">
          
  
          <div className="row">
            <div className="col-12 col-lg-3 col-xl-3">
              <div className="row mb-2">
                <div className="col-12 col-lg-12 col-xl-12 d-flex">
                  <div className=" card w-100 p-4">
                      <div className="list-unstyled topbar-nav">
                        <li className="hide-phone">
                          <form role="search" className="">
                            {/* <input
                              type="text"
                              //   onkeyup="myFunction()"
                              placeholder="Search..."
                              className="form-control"
                            /> */}
                            <AdvSelect/>
                          </form>
                        </li>
                      </div>
                     
                      {/* <Tree datacenters={ }/> */}
                  </div>
                </div>
              </div>
            </div>
  
            <div className="col-12 col-lg-9 col-xl-9 d-flex">
              <div className="row g21">
              <DynamicChart
                ChartComp={<SunburstS />}
                name="Classification Of Complaints"
                screen="col-12 col-lg-4 col-xl-4 d-flex"
               />
                   <DynamicChart
                ChartComp={<SunburstS />}
                name="Classification Of Complaints"
                screen="col-12 col-lg-4 col-xl-4 d-flex"
               />
                   <DynamicChart
                ChartComp={<SunburstS />}
                name="Classification Of Complaints"
                screen="col-12 col-lg-4 col-xl-4 d-flex"
               />
                   <DynamicChart
                ChartComp={<SunburstS />}
                name="Classification Of Complaints"
                screen="col-12 col-lg-4 col-xl-4 d-flex"
               />
              <div >
       
             
     </div>
                
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };
  
 
  export default   Adv;