import React from "react";
import "./Cardadvice.css";
function CardAdvice({ IssueDescrip, RecomendationDescrip }) {
  const handleButton1Click = () => {
    // handle button 1 click event here
  };

  const handleButton2Click = () => {
    // handle button 2 click event here
  };

  return (
    <div className="card">
      <div className="title">
        <div> Issue</div>
        <div className="log1">
          <img src="./images/solid-waste-management.png" alt="" />{" "}
        </div>
      </div>
      <div className="row">
        <p className="m-2 p-3">{IssueDescrip}</p>
      </div>

      <div className=" row title">Recomendation</div>
    
      <p className="m-2 p-3">{RecomendationDescrip}</p>
      <div className="button-row">
        <button
         type="button"
         class="btn btn-light"
        onClick={handleButton1Click}>Ignore</button>
        <button
          type="button"
          class="btn btn-danger"
          onClick={handleButton2Click}
        >
          view
        </button>
      </div>
    </div>
  );
}

export default CardAdvice;
