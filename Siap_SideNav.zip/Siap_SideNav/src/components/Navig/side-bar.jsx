import { Link } from 'react-router-dom';
import './side-bar.css'


const SideBar = () => {
    

    return (
        <div className="side-bar">
            <a className="lunch-icon1"  type="button" data-bs-toggle="offcanvas" data-bs-target="#staticBackdrop" aria-controls="staticBackdrop">
                <img src="./images/Icon.png"  alt="" className="lunch-icon" />
            </a>

            <div className="offcanvas" data-bs-backdrop="static" tabindex="-1" id="staticBackdrop" aria-labelledby="staticBackdropLabel">
                <div className="offcanvas-header">
                    <h5 className="offcanvas-title" id="staticBackdropLabel"></h5>
                    <a type="button" data-bs-dismiss="offcanvas" aria-label="Close" > <img src="./images/Launch Icon.png" alt="" className="lunch-icon2" /></a>
                </div>


                <div className="offcanvas-nav">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <div><img className="nav-icons" src="./images/dashboard.svg" alt="" /></div>
                            <div><Link to="./dashboard" className="nav-link" aria-current="page" >Dashboard</Link></div>
                        </li>
                        <li className="nav-item">
                            <div><img className="nav-icons" src="./images/analytics.svg" alt="" /></div>
                            <div><Link to="./Analytics" className="nav-link" >Analytics</Link></div>
                        </li>
                        <li className="nav-item">
                            <div><img className="nav-icons" src="./images/datascience.svg" alt="" /></div>
                            <div><Link to="/Datasrc" className="nav-link" >Data Source</Link></div>
                        </li>
                        <li className="nav-item">
                            <div><img className="nav-icons" src="./images/MLworkbench.svg" alt="" /></div>
                            <div><Link to="/MlWorkBench" className="nav-link">ML Workbench</Link></div>
                        </li>
                        <li className="nav-item">
                            <div><img className="nav-icons" src="./images/advice.svg" alt="" /></div>
                            <div><Link to="/Advice" className="nav-link">Advice</Link></div>
                        </li>
                        <li className="nav-item">
                            <div><img className="nav-icons" src="./images/settings.svg" alt="" /></div>
                            <div><Link to="/Settings" className="nav-link">Setting</Link></div>
                        </li>
                    </ul>

                </div>

            </div>
        </div>
    );
}

export default SideBar;