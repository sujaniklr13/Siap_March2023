import React, { useState } from 'react'
import { NavLink } from 'react-router-dom'


function Nav() {
  return (
    <div>
   
   <NavLink exact to='/'  className={({ isActive }) => isActive ? styles.active_class : styles.non_active_class} onClick={()=>itemClickHandler("/")}>Dashboard</NavLink>
        
    </div>
  )
}

export default Nav