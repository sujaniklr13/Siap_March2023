import React from "react";
import "./newTopBar.css";
function NewTopBar() {
  return (
    <div class="nav-bar">
      <div  class='nav-bar-1'>
      <div  class='nav-bar-2'>hiiii-2</div>
      <div  class='nav-bar-2'>hiiii-21</div>
      </div>
     
      <div  class='nav-bar-3'>hi -3</div>
    </div> 
  );
}

export default NewTopBar;
