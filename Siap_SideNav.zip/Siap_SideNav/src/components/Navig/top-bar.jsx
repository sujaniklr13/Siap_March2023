import React, { useState } from "react";

import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import Offcanvas from "react-bootstrap/Offcanvas";
import { Link, useLocation } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";
import useBreadcrumbs from 'use-react-router-breadcrumbs'
import "./top-bar.css";

function TopBar() {
  const location = useLocation();
  const [modal, setModal] = useState(false);

  const [active, setActive] = useState(false);

  const modalHandler = () => {
    setModal(!modal);
  };
  const itemClickHandler = (click) => {
    setModal(false);
    if (click === "env") {
      setActive(true);
    } else {
      setActive(false);
    }
  };
  const [path, setPath] = useState([
    { label: "Dashboard", link: "/" },
    { label: "Solid Waste Management", link: "/SolidWastemanagment" },
  ]);

  return (
    <>
      <div className="top-bar">
        <nav className="nav">
          <div className="contain">
            <div>
            <a className="nav-brand" href="#">
              <img
                src="/images/logo.svg"
                alt="Bootstrap"
                width="99"
                height="32"
              />
            </a>
            </div>
            <div className="breadcrumbs">
          <Link to="/Dashboard">Dashboard</Link> 
            {location.pathname.startsWith("/SolidWastemanagment") && (
              <Link to="/SolidWastemanagment">
                <span style={{marginLeft: "10px", marginRight: "10px"}} className="breadcrumb-arrow">&gt;</span>
                Solid Waste Management 
              </Link>
            )}
            {location.pathname.endsWith("/classificationOfComplains") && (
              <Link to="/SolidWastemanagment/classificationOfComplains">
                <span style={{marginLeft: "10px", marginRight: "10px"}} className="breadcrumb-arrow">&gt;</span>
                Classification of Complaints 
              </Link>
            )}
           </div>

            </div>
          
          
           <div className="contain1">
      
            <a className="nav-brand" href="#">
              <img
                src="/images/Bell.svg"
                alt="Bootstrap"
                // width="80"
                // height="32"
              />
            </a>
            <a className="nav-brand" href="#">
              <img
                src="/images/usr.svg"
                alt="Bootstrap"
                // width="99"
                // height="32"
              />
               </a>
              <p>
              Username
           </p>
         
            </div>   
        </nav>
      </div>
    </>
  );
}

export default TopBar;
// import Breadcrumb from 'react-bootstrap/Breadcrumb';

// function BreadcrumbExample() {
//   return (
//     <Breadcrumb>
//       <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
//       <Breadcrumb.Item href="https://getbootstrap.com/docs/4.0/components/breadcrumb/">
//         Library
//       </Breadcrumb.Item>
//       <Breadcrumb.Item active>Data</Breadcrumb.Item>
//     </Breadcrumb>
//   );
// }

// export default BreadcrumbExample;
