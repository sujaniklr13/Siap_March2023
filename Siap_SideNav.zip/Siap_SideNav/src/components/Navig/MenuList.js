
// export const SERVER_URL  = process.env.SERVER_URL || "http://192.168.0.124:9000/";
const MAIN_DOMAIN = "";
const mainDomain = MAIN_DOMAIN
export const MenuList=[

{
    title:"Dashboard",
    url: mainDomain.concat("dashboard"),
    icon:"./images/dashboard.svg",
    Regions1:[
        {
            Subtitle1:"Solid Waste Managment ",
            Suburl1 :mainDomain.concat("SolidWastemanagment"),
            SubIcon1:"",
            Region2:[
                {
                    Subtitle2:"Classification of Complaints",
                    Suburl2 :mainDomain.concat("ClassificationOfComplaints"),
                    SubIcon2:"",
            },
            {
                Subtitle2:"Complains Comparition",
                Suburl2 :mainDomain.concat("ComplainsComparition"),
                SubIcon2:""
        },
        {
            Subtitle2:"Total Complaints Comparition",
            Suburl2 :mainDomain.concat("TotalComplaintsComparition"),
            SubIcon2:""
    },
    {
        Subtitle2:"Complaints Reported Across all Zones  ",
        Suburl2 :mainDomain.concat("ComplaintsReportedZone"),
        SubIcon2:""
},
{
    Subtitle2:"Total Complaints Across Zones ",
    Suburl2 :mainDomain.concat("TotalComplaintsZones"),
    SubIcon2:""
},
{
    Subtitle2:"Percentage of Closed Complaints",
    Suburl2 :mainDomain.concat("PercentageClosedComplaints"),
    SubIcon2:""
},

            ]
    },
    {
        Subtitle1:"CCTV Status ",
        Suburl1 :"",
        SubIcon1:""
},
{
    Subtitle1:"AQI",
    Suburl1 :"",
    SubIcon1:""
},
{
    Subtitle1:"Traffic",
    Suburl :"",
    SubIcon1:""
},
]
},
{
    title:"Analytics",
    url: mainDomain.concat("Analytics"),
    icon:"./images/analytics.svg"
},
{
    title:"/Data Source",
    url:mainDomain.concat("Datasrc"),
    icon:"./images/datascience.svg"
},
{
    title:"ML Workbench",
    url:mainDomain.concat("MlWorkBench"),
    icon:"./images/MLworkbench.svg"
},
{
    title:"Advice",
    url:mainDomain.concat("Advice"),
    icon:"./images/advice.svg"
},
{
    title:"Setting",
    url:mainDomain.concat("Settings"),
    icon:"./images/settings.svg"
},

{
    title:"",
    url: mainDomain,
    icon:""
},
]
