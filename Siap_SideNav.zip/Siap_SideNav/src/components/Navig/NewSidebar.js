import React from 'react'
import {MenuList} from "./MenuList"
import { Link } from 'react-router-dom';
import './side-bar.css'
// import { MAIN_DOMAIN } from '../../config';
const MAIN_DOMAIN = "";
function NewSidebar() {
  const mainDomain = MAIN_DOMAIN;
    const [navState, setNavState] = React.useState(false);
    // const menuList = MenuList.map(({ url, title, icon, subitem }, index) => {
    //   return (
    //     <li key={index}>
    //       {title === "Data Center" ? (
    //         <div onMouseEnter={() => setNavState(!navState)} onMouseLeave={() => setNavState(!navState)} active className="active">
    //           <span className="icon1">
    //             <Icon icon={icon} style={{ width: 25, height: 25 }} />
    //           </span>
    //           {title}
    //           {title === "Data Center" && navState ? (
    //             <div class="dropdown-content">
                 
    //               <Link to={mainDomain.concat("ngdc")}><Icon className="icon2" icon="bx:bx-lock" />NGDC</Link>  
    //               <Link to={mainDomain.concat("InfraCapsule")}><Icon className="icon2" icon="bx:bx-lock" />InfraCapsule</Link>
    //               <Link to={mainDomain.concat("Colo")}><Icon className="icon2" icon="bx:bx-lock" />COLO</Link>
    //               <Link to={mainDomain.concat("MsrHub")}><Icon className="icon2" icon="bx:bx-lock" />MSR/HUB</Link>
                
    //             </div>
    //           ) : (
    //             ""
    //           )}
    //         </div>
    //       ) : (
    //         <NavLink exact to={url} active className="active">
    //           <span className="icon1">
    //             <Icon icon={icon} style={{ width: 25, height: 25 }} />
    //           </span>
    //           {title}
    //         </NavLink>
    //       )}
    //     </li>
    //   );
    // });
    const menuList = MenuList.map(({ url, title, icon, subitem }, index) => {
          return ( 
<div>
    
</div>
          );
         });
    return (
      <nav className="nav-top">
         <Header/> 
         
          <div className="menu-list">
              
       {menuList}
          </div>
      </nav>
   )
}

export default NewSidebar
