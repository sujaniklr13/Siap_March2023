import React from 'react'

function Analytics() {
  return (
    <div className="graph-container">
     <h1>  this is under development Analytics
        </h1>
        </div>
  )
}

export default Analytics